function $$(selector, container) {
    return (container || document).querySelector(selector);
}

function fnScanReceived(params) {
    if (params['data'] == "" || params['time'] == "") {
        $$('#barcode').innerHTML = "Failed!";
        return;
    }

    var displayStr = "Barcode Data: " + params['data'] + "<br>Time: " + params['time'];
    $$("#barcode").innerHTML = displayStr + "<br>" + JSON.stringify(params);;
}

function keyCallback(params) {
    console.log("this key has just been pressed!: " + params['keyValue']);
    if (79 === params.keyValue) {
        EB.Barcode.start();
    }
}

(function() {
    var buttons = {
        quit: $$('button.quit'),
    };

    buttons.quit.addEventListener('click', function() {
        EB.Application.quit();
    });

    EB.KeyCapture.captureKey(false, "228", keyCallback);
    EB.KeyCapture.captureKey(false, "79", keyCallback);

    $$('#scanner').addEventListener('change', function() {
        if (this.checked) {
            EB.Barcode.enable({ allDecoders: true }, fnScanReceived);
            $$('#scannerLabel').innerHTML = "Scanner Enabled";
        } else {
            EB.Barcode.disable();
            $$('#scannerLabel').innerHTML = "Scanner Disabled";
        }
    });
})();