package com.symbol.syncadapter;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.symbol.contentprovider.DataProvider;

import android.accounts.Account;
import android.content.AbstractThreadedSyncAdapter;
import android.content.ContentProviderClient;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SyncResult;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.RemoteException;
import android.preference.PreferenceManager;
import android.provider.Settings.Secure;
import android.util.Log;

public class SyncAdapter extends AbstractThreadedSyncAdapter
{
	private static final String TAG = "Sync";
	private static final String LAST_UPDATE = "last";
	private static final String WEB_SERVICE = "http://stockchecker.emb-sc.com:9180/sync.php";
	private static long sLastSyncTime = 0;

	ContentResolver mContentResolver;
	Context mContext;

	/*********************************************************************************************************/
	public SyncAdapter(Context context, boolean autoInitialize)
	{
		super(context, autoInitialize);
		mContentResolver = context.getContentResolver();
		mContext = context;
	}

	/*********************************************************************************************************/
	public SyncAdapter(Context context, boolean autoInitialize, boolean allowParallelSyncs)
	{
		super(context, autoInitialize, allowParallelSyncs);
		mContentResolver = context.getContentResolver();
		mContext = context;
	}

	/*********************************************************************************************************/
	private static String getQuery(List<NameValuePair> params) throws UnsupportedEncodingException
	{
		StringBuilder result = new StringBuilder();
		boolean first = true;

		for (NameValuePair pair : params)
		{
			if (first)
				first = false;
			else
				result.append("&");

			result.append(URLEncoder.encode(pair.getName(), "UTF-8"));
			result.append("=");
			result.append(URLEncoder.encode(pair.getValue(), "UTF-8"));
		}
		return result.toString();
	}

	/*********************************************************************************************************/
	private static String convertStreamToString(InputStream is)
	{
		Scanner s = new Scanner(is).useDelimiter("\\A");
		return s.hasNext() ? s.next() : "";
	}

	/*********************************************************************************************************/
	private void getUpdateFromServer(Account account, Bundle extras, String authority, ContentProviderClient provider, SyncResult syncResult)
	{
		SharedPreferences prefs;
		String mLastSyncTime;
		URL configURL;
		JSONObject jsonObj;

		// Get Last Store Sync Time
		prefs = PreferenceManager.getDefaultSharedPreferences(mContext);
		mLastSyncTime = prefs.getString(LAST_UPDATE, "");

		try
		{
			// Connect to Web Service for Update
			String Url = WEB_SERVICE;
			if (!Url.endsWith("?"))
				Url += "?";

			// Add Parameters to URL
			String android_id = Secure.getString(getContext().getContentResolver(), Secure.ANDROID_ID);
			List<NameValuePair> GetParams = new ArrayList<NameValuePair>();
			GetParams.add(new BasicNameValuePair("last", mLastSyncTime));
			GetParams.add(new BasicNameValuePair("deviceId", android_id));
			Url += getQuery(GetParams);

			// Setup URL Connection
			configURL = new URL(Url);
			HttpURLConnection conn = (HttpURLConnection) configURL.openConnection();
			conn.setDoInput(true);
			conn.setRequestMethod("GET");
			Log.i(TAG, "*** GET ->" + configURL.toString());

			// Request Data
			conn.connect();
			InputStream stream = conn.getInputStream();
			String data = convertStreamToString(stream);
			Log.i(TAG, "*** Result -> " + data);
			jsonObj = new JSONObject(data);
			stream.close();

			// Add Data To Data Provider
			JSONArray payLoad = jsonObj.getJSONArray("payload");
			Log.i(TAG, "Recieved " + payLoad.length() + " Entries");

			// Insert all the new elements.
			for (int i = 0; i < payLoad.length(); i++)
			{
				ContentValues vals = new ContentValues();

				// Is item marked for deletion
				if (payLoad.getJSONObject(i).getBoolean("deleted") == true)
				{
					provider.delete(Uri.parse("content://" + DataProvider.PROVIDER_NAME + "/" + DataProvider.STOCK_DATABASE_TABLE), DataProvider.STOCK_CODE + "='" + payLoad.getJSONObject(i).getString("id")
							+ "'", null);
				} else
				{
					// Insert or update Item
					vals.put(DataProvider.STOCK_CODE, payLoad.getJSONObject(i).getJSONObject("data").getString("code"));
					vals.put(DataProvider.STOCK_DESCRIPTION, payLoad.getJSONObject(i).getJSONObject("data").getString("description"));
					vals.put(DataProvider.STOCK_QUANTITY, payLoad.getJSONObject(i).getJSONObject("data").getString("qty"));
					vals.put(DataProvider.STOCK_PRICE, payLoad.getJSONObject(i).getJSONObject("data").getString("price"));
					vals.put(DataProvider.REMOVE_UPDATE_FLAG, true);
					provider.insert(DataProvider.STOCK_URI, vals);
				}
			}

			// Save Last Update Time
			prefs.edit().putString(LAST_UPDATE, jsonObj.getString("lastupdate")).commit();
			Log.i(TAG, "Setting last Server Update " + jsonObj.getString("lastupdate"));
			sLastSyncTime = (new Date().getTime());

		} catch (MalformedURLException e)
		{
			syncResult.stats.numIoExceptions = 1;
			e.printStackTrace();
		} catch (UnsupportedEncodingException e)
		{
			syncResult.stats.numIoExceptions = 1;
			e.printStackTrace();
		} catch (ProtocolException e)
		{
			syncResult.stats.numIoExceptions = 1;
			e.printStackTrace();
		} catch (IOException e)
		{
			syncResult.stats.numIoExceptions = 1;
		} catch (JSONException e)
		{
			syncResult.stats.numParseExceptions = 1;
		} catch (RemoteException e)
		{
			syncResult.stats.numParseExceptions = 1;
			e.printStackTrace();
		}
	}

	/*********************************************************************************************************/
	private void postUpdatesToServer(Account account, Bundle extras, String authority, ContentProviderClient provider, SyncResult syncResult)
	{
		URL configURL;
		JSONObject jsonObj;
		JSONObject payload;
		JSONObject data;
		JSONArray jsonArray;
		Boolean bDeleted;
		String code;

		try
		{
			jsonObj = new JSONObject();
			jsonArray = new JSONArray();
			Cursor c = provider.query(DataProvider.UPDATE_URI, null, null, null, null);
			if (c == null || c.moveToFirst() == false)
				return;

			// Create JSON object from updates table
			while (!c.isAfterLast())
			{
				bDeleted = c.getInt(c.getColumnIndex("update_type")) == 2 ? true : false;
				code = c.getString(c.getColumnIndex(DataProvider.STOCK_CODE));

				payload = new JSONObject();
				data = new JSONObject();
				payload.put("id", code);
				payload.put("deleted", bDeleted);
				if (bDeleted == false)
				{
					// Get Data from stock Item
					Cursor d = provider.query(DataProvider.STOCK_URI, null, DataProvider.STOCK_CODE + "='" + code + "'", null, null);
					if (d != null)
					{
						d.moveToFirst();
						data.put(DataProvider.STOCK_CODE, d.getString(d.getColumnIndex(DataProvider.STOCK_CODE)));
						data.put(DataProvider.STOCK_DESCRIPTION, d.getString(d.getColumnIndex(DataProvider.STOCK_DESCRIPTION)));
						data.put(DataProvider.STOCK_PRICE, d.getDouble(d.getColumnIndex(DataProvider.STOCK_PRICE)));
						data.put(DataProvider.STOCK_QUANTITY, d.getInt(d.getColumnIndex(DataProvider.STOCK_QUANTITY)));
					}
				}
				payload.put("data", data);
				jsonArray.put(payload);
				c.moveToNext();
			}

			// Add Payload packet to Json Array
			jsonObj.put("payload", jsonArray);

			// Connect to Web Service for Update
			String Url = WEB_SERVICE;
			if (!Url.endsWith("?"))
				Url += "?";

			// Add Parameters to URL
			String android_id = Secure.getString(getContext().getContentResolver(), Secure.ANDROID_ID);
			List<NameValuePair> Params = new ArrayList<NameValuePair>();
			Params.add(new BasicNameValuePair("deviceId", android_id));
			Url += getQuery(Params);

			// Setup URL Connection
			configURL = new URL(Url);
			HttpURLConnection conn = (HttpURLConnection) configURL.openConnection();
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			Log.i(TAG, "*** POST ->" + configURL.toString());

			// Send Update to Server
			OutputStream os = conn.getOutputStream();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
			writer.write(jsonObj.toString(1));
			Log.i("Network", "*** POST Params -> " + jsonObj.toString());
			writer.flush();
			writer.close();
			os.close();

			// If Update was successful, remove updates from update table.
			if (conn.getResponseCode() == HttpURLConnection.HTTP_OK)
				c.moveToFirst();
			while (!c.isAfterLast())
			{
				provider.delete(DataProvider.UPDATE_URI, DataProvider.STOCK_CODE + "='" + c.getString(c.getColumnIndex("code")) + "'", null);
				c.moveToNext();
			}

		} catch (MalformedURLException e)
		{
			syncResult.stats.numIoExceptions = 1;
			e.printStackTrace();
		} catch (UnsupportedEncodingException e)
		{
			syncResult.stats.numIoExceptions = 1;
			e.printStackTrace();
		} catch (RemoteException e)
		{
			syncResult.stats.numIoExceptions = 1;
			e.printStackTrace();
		} catch (ProtocolException e)
		{
			syncResult.stats.numIoExceptions = 1;
			e.printStackTrace();
		} catch (JSONException e)
		{
			syncResult.stats.numParseExceptions = 1;
			e.printStackTrace();
		} catch (IOException e)
		{
			syncResult.stats.numIoExceptions = 1;
			e.printStackTrace();
		}

	}

	/*********************************************************************************************************/
	@Override
	public void onPerformSync(Account account, Bundle extras, String authority, ContentProviderClient provider, SyncResult syncResult)
	{
		Log.i(TAG, "onPerformSync");

		// Ignore Request if last Sync was within 5 seconds
		Date now = new Date();
		if (sLastSyncTime > 0 && now.getTime() - sLastSyncTime < 5000)
		{
			Log.i(TAG, "Sync was canceled, due to last sync within 5 seconds");
			return;
		}

		// Get new updates from server.
		getUpdateFromServer(account, extras, authority, provider, syncResult);

		// Send Updates to Server
		postUpdatesToServer(account, extras, authority, provider, syncResult);

	}
}
