package com.symbol.workshop;

import android.os.Bundle;
//import android.support.v4.content.LocalBroadcastManager;
import android.accounts.Account;
//import android.accounts.AccountManager;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;

/*
 * Some external entity is telling us that the database
 * has been updated.  Send a request to synchronize the
 * local data store with the remote store
 */

// FIXME Hard coded strings.

public class UpdateReceiver extends BroadcastReceiver
{
	private Account account = new Account("Symbol", "com.symbol.database.account");
	private Bundle bundle = new Bundle();
	
	@Override 
	public void onReceive(Context context, Intent intent)
	{
		ContentResolver.requestSync(account, "com.symbol.database.provider", bundle);
	}
} 