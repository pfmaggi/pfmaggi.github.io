package com.symbol.workshop;


import com.symbol.contentprovider.DataProvider;
import com.symbol.mqtt.MQTT;
import com.symbol.emdk.EMDKManager;
import com.symbol.emdk.EMDKResults;
import com.symbol.emdk.ProfileManager;
import com.symbol.emdk.EMDKManager.EMDKListener;

import android.support.v7.app.ActionBarActivity;
import android.content.Loader;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.app.FragmentManager;
import android.app.ListFragment;
import android.app.LoaderManager;



public class MainActivity extends ActionBarActivity implements EMDKListener 
{
	private Context context = null;
	private Account account = null;
	private IntentFilter intentFilter = null;
	private EMDKReceiver EMDKreceiver = null;
	private EMDKManager emdkManager = null;
	private ProfileManager profileManager = null;
	
	

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        context = this;
        String tid = Integer.valueOf(this.getTaskId()).toString(); 
        
        Log.d(this.getClass().getCanonicalName() + ":" + tid, "Oncreate");
        
    	intentFilter = new IntentFilter();
    	intentFilter.addAction("com.symbol.workshop.LOOKUP");
    	EMDKreceiver = new EMDKReceiver();
    	this.registerReceiver(EMDKreceiver, intentFilter, null, null);
    	
        /*
         * MQTT push message service, tell it which class to launch when
         * a notification is opened.
         */
    	startService(new Intent(this, MQTT.class));
		MQTT.setPushCallback(MainActivity.class);

	        
		/*
		 * BEGIN datasync
		 */
		account = new Account("Symbol", "com.symbol.database.account");
		AccountManager accountManager = (AccountManager) getSystemService(Context.ACCOUNT_SERVICE);
		accountManager.addAccountExplicitly(account, null, null);
		ContentResolver.setSyncAutomatically(account, "com.symbol.database.provider", true);
		Bundle bundle = new Bundle();
		ContentResolver.requestSync(account, "com.symbol.database.provider", bundle);
		/*
		 * END datasync
		 */
		
		
		EMDKResults results = EMDKManager.getEMDKManager(getApplicationContext(), this);
		
		    //Check the return status of EMDKManager object creation.
		if(results.statusCode == EMDKResults.STATUS_CODE.SUCCESS)
		{
			//EMDKManager object creation success
		}
		else
		{
			//EMDKManager object creation failed
		}	
		
        setContentView(R.layout.activity_main);

        FragmentManager fm = getFragmentManager();  	
        if (savedInstanceState == null) {
            fm.beginTransaction()
                    .add(R.id.container, new ListManager())
                    .commit();
        }
    }
    
    
     @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {   
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
       
        switch (item.getItemId())
        {
        case R.id.action_settings:
        {
          	Intent intent = new Intent(this, Settings.class);
        	startActivity(intent);
        	return true;
        }
        case R.id.action_addProduct:
        {
        	Intent intent = new Intent(this, BarcodeEntry.class);
        	startActivity(intent);
        	return true;
        }
        }
        return super.onOptionsItemSelected(item);
    }
    
	   @Override
	    protected void onResume()
	   {
	        super.onResume();
	        registerReceiver(EMDKreceiver, intentFilter);
	    }

	    @Override
	    protected void onPause()
	    {
	        super.onPause();
	        unregisterReceiver(EMDKreceiver);
	    }
	

	    public class EMDKReceiver extends BroadcastReceiver
	    {
			@Override
			public void onReceive(Context context, Intent i)
			{
				String barcode = i.getStringExtra("com.symbol.datawedge.data_string");
				
	        	Intent intent = new Intent(context, ProductDetail.class);
	        	intent.putExtra("code", barcode);
	        	startActivity(intent);
			}
	    }
    
     public static class ListManager extends ListFragment implements LoaderManager.LoaderCallbacks<Cursor>
    {
    	
    	private ButtonCursorAdapter adapter = null;
    	private static final String[] PROJECTION = 
    									{ 
    										"rowid _id",
    										DataProvider.STOCK_CODE,
    										DataProvider.STOCK_DESCRIPTION, 
    										DataProvider.STOCK_PRICE,
    										DataProvider.STOCK_QUANTITY
    									};
    	private static final int LOADER_ID = 1;
    	private LoaderManager.LoaderCallbacks<Cursor> callbacks;

        public ListManager()
        {
        	callbacks = this;
        }
                     
        @Override  
        public void onListItemClick(ListView l, View v, int position, long id)
        {  
        	Cursor c = (Cursor) getListAdapter().getItem(position);
        	String code = c.getString(c.getColumnIndex(DataProvider.STOCK_CODE));
       	
           	Intent intent = new Intent(getActivity(), ProductDetail.class);
        	intent.putExtra("code", code);
        	startActivity(intent);
        }  
        
          @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
           
    		String[] columns = 
    			{ 
    	 				DataProvider.STOCK_CODE,
    	 				DataProvider.STOCK_DESCRIPTION, 
    	 				DataProvider.STOCK_QUANTITY,
    	 				DataProvider.STOCK_PRICE
    			};
    			int[] views =
    			{
    	 			R.id.STOCK_CODE, 
    	 			R.id.STOCK_DESCRIPTION,
    	 			R.id.STOCK_QUANTITY,
    	 			R.id.STOCK_PRICE
    			};
    		
    			adapter = new ButtonCursorAdapter(getActivity(), 
    	 							R.layout.list_row,
    	 							null,
    	 							columns,
    	 							views,
    	 							0);
    		

    			setListAdapter(adapter);
    			getLoaderManager().initLoader(LOADER_ID, null, callbacks);
            
            return super.onCreateView(inflater, container, savedInstanceState);
        }

        /*
         * (non-Javadoc)
         * @see android.app.LoaderManager.LoaderCallbacks#onCreateLoader(int, android.os.Bundle)
         * 
         * Callback function implementation.
         */
        @Override
        public Loader<Cursor> onCreateLoader(int id, Bundle args)
        {
          // Create a new CursorLoader with the following query parameters.
          return new CursorLoader(this.getActivity(), DataProvider.STOCK_URI, PROJECTION, null, null, DataProvider.STOCK_CODE);
        }

        @Override
        public void onLoadFinished(Loader<Cursor> loader, Cursor cursor)
        {
          // A switch-case is useful when dealing with multiple Loaders/IDs
          switch (loader.getId())
          {
            case LOADER_ID:
              // The asynchronous load is complete and the data
              // is now available for use. Only now can we associate
              // the queried Cursor with the SimpleCursorAdapter.
              adapter.swapCursor(cursor);
              break;
          }
        }

        @Override
        public void onLoaderReset(Loader<Cursor> loader)
        {
          // For whatever reason, the Loader's data is now unavailable.
          // Remove any references to the old data by replacing it with
          // a null Cursor.
          adapter.swapCursor(null);
        }
    }

	@Override
	public void onClosed() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onOpened(EMDKManager manager)
	{
		emdkManager = manager;
		profileManager = (ProfileManager) emdkManager.getInstance(EMDKManager.FEATURE_TYPE.PROFILE);
		profileManager.processProfile("ProductDetail", ProfileManager.PROFILE_FLAG.SET, new String[1]);
	}
}
