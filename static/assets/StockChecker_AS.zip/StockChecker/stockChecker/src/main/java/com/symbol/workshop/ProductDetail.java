package com.symbol.workshop;

import java.util.Set;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.symbol.contentprovider.DataProvider;
import com.zebra.sdk.comm.BluetoothConnection;
import com.zebra.sdk.comm.ConnectionException;
import com.zebra.sdk.printer.ZebraPrinter;
import com.zebra.sdk.printer.ZebraPrinterFactory;
import com.zebra.sdk.printer.ZebraPrinterLanguageUnknownException;

public class ProductDetail extends Activity
{
	private Context context = null;
	private TextView barcode = null;
	private TextView description = null;
	private TextView price = null;
	private TextView quantity = null;
	private IntentFilter intentFilter = null;
	private EMDKReceiver EMDKreceiver = null;
	private InputMethodManager inputMethodManager = null;
	private static String TAG = null;
	
	// Intent request codes
    public static final int REQUEST_PAIR_DEVICE = 1;
    public static final int REQUEST_ENABLE_BT = 2;
	
	private String mPairedPrinterAddress = null;
	private BluetoothAdapter mBluetoothAdapter = null;
	

	@Override
	protected void onCreate(Bundle bundle)
	{
		super.onCreate(bundle);
		setContentView(R.layout.product_detail);
		context = this;
		
		TAG = getClass().getCanonicalName();
		
	 	barcode = (TextView)findViewById(R.id.barcode);
		description = (TextView)findViewById(R.id.description);
		price = (TextView)findViewById(R.id.price);
		quantity = (TextView)findViewById(R.id.quantity);
		
		inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		
	   	intentFilter = new IntentFilter();
    	intentFilter.addAction("com.symbol.workshop.LOOKUP");
    	EMDKreceiver = new EMDKReceiver();
    	this.registerReceiver(EMDKreceiver, intentFilter, null, null);
    		
		/*
		 * This activity should be started from an intent that
		 * has a key/value pair, the key is "code" and the 
		 * data is the key into the database.
		 */
		lookupProduct(getIntent().getStringExtra("code"));
		
		
		// get stored printer bt address from shared preferences
		SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
		mPairedPrinterAddress = prefs.getString("printerAddress", "None");
		updateDeviceName();
		
		// try to get BT adapter
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if (mBluetoothAdapter == null) {
		    Toast.makeText(this, "Device doesn't support bluetooth!", Toast.LENGTH_LONG).show();
		    finish();
		}
		else {
			// try to turn BT on
			if (!mBluetoothAdapter.isEnabled()) {
	            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
	            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
			}
		}
	}
	
	private void lookupProduct(String code)
	{
		Cursor c = null;
		inputMethodManager.hideSoftInputFromWindow(barcode.getWindowToken(), 0);
		
		if (code != null && (code.trim()).isEmpty() == false)
		{
			/*
			 * Search database to find the data associated using the key 
			 * that was passed in.
			 */
			c = getContentResolver().query(DataProvider.STOCK_URI,
											null,
											DataProvider.STOCK_CODE + "= ?" ,
											new String[] { code },
											null);
		}
				
		if (c == null || c.getCount() == 0)
		{
			Toast.makeText(context, "Error item: " + code + " not found.", Toast.LENGTH_LONG).show();
		}
		else
		{
			c.moveToFirst();					
			barcode.setText(code);
			description.setText(c.getString(c.getColumnIndex(DataProvider.STOCK_DESCRIPTION)));
			price.setText(c.getString(c.getColumnIndex(DataProvider.STOCK_PRICE)));
			quantity.setText(c.getString(c.getColumnIndex(DataProvider.STOCK_QUANTITY)));
		}
	}



	   @Override
	    protected void onResume()
	   {
	        super.onResume();
	        registerReceiver(EMDKreceiver, intentFilter);
	    }

	    @Override
	    protected void onPause()
	    {
	        super.onPause();
	        unregisterReceiver(EMDKreceiver);
	    }
	
	    public class EMDKReceiver extends BroadcastReceiver
	    {
			@Override
			public void onReceive(Context context, Intent intent)
			{
				lookupProduct(intent.getStringExtra("com.symbol.datawedge.data_string"));
			}
	    }
	    
	    
		public void printClicked(View v) {
			
			// check if mPairedPrinter value is a BT device we are paired to	
			if (mPairedPrinterAddress == null || mPairedPrinterAddress.equals("None")) {
				// no pairing is remembered, prompt user to pick
				Intent pairIntent = new Intent(this, PairActivity.class);
	            startActivityForResult(pairIntent, REQUEST_PAIR_DEVICE);
			}
			else if (!checkIfPaired(mPairedPrinterAddress)) {
				// device is not in the paired list, need to re pair
				Intent pairIntent = new Intent(this, PairActivity.class);
	            startActivityForResult(pairIntent, REQUEST_PAIR_DEVICE);
			}
			else {
				// device is paired so just print
				
				printLabel();
			}
		}
		
		private void printLabel()
		{
			String[] textToPrint = new String[5];
			textToPrint[0] = barcode.getText().toString();
			textToPrint[1] = "Code: " + barcode.getText().toString();
			textToPrint[2] = "Description: " + description.getText().toString();
			textToPrint[3] = "Quantity: " + quantity.getText().toString();
			textToPrint[4] = "Price: " + price.getText().toString();
			new printTask().execute(textToPrint);
		}
		
		private Boolean checkIfPaired(String btAddress) {
			// check to make sure the selected printer is in the paired list
			Set<BluetoothDevice> pairedDevices = mBluetoothAdapter
					.getBondedDevices();
			if ((pairedDevices != null) && (!pairedDevices.isEmpty())) {
				for (BluetoothDevice bluetoothDevice : pairedDevices) {
					if ((bluetoothDevice.getAddress() != null)
							&& (bluetoothDevice.getAddress()
									.equals(btAddress))) {
						return true;
					}
				}
			}
			return false;
		}
		
		// asynchronous task to perform the printing in a background thread
		private class printTask extends AsyncTask<String, Void, Void> {
			
			@Override
			protected void onPreExecute() {
				// show progress
				showProgressIndicator(true);
				
				// disable print button
				enablePrintButton(false);
			}
		
			@Override
			protected Void doInBackground(String... params) {
				doPrint(params);
				return null;
			}
			
			@Override
			protected void onPostExecute(Void result) {
				Log.d(TAG, "post execute");
				showProgressIndicator(false);
				
				// enable print button
				enablePrintButton(true);
			}
		}

		// start the printing process
		private void doPrint(String[] text) {
			BluetoothConnection connection = new BluetoothConnection(mPairedPrinterAddress);
			try {
	            connection.open();
	        } catch (ConnectionException e) {
	        	e.printStackTrace();
	            disconnect(connection);
	        }

	        ZebraPrinter printer = null;

	        if (connection.isConnected()) {
	            try {
	                printer = ZebraPrinterFactory.getInstance(connection);
	                sendTestLabel(connection, printer, text);
	            } catch (ConnectionException e) {
	            	e.printStackTrace();
	                printer = null;
	                disconnect(connection);
	            } catch (ZebraPrinterLanguageUnknownException e) {
	            	e.printStackTrace();
	                printer = null;
	                disconnect(connection);
	            }
	        }
		}
		
		// generate label to print
		private byte[] getConfigLabel(ZebraPrinter printer, String[] text) {
			
		
		    //String cpclConfigLabel = "! 0 200 200 406 1\r\n" + "ON-FEED IGNORE\r\n" + "T 0 6 137 177 Product Name\r\n" + "B 128 3 30 40 86 280 123456789\r\n" + "PRINT\r\n";
            String cpclConfigLabel = "! 0 200 200 406 1\r\n" + "ON-FEED IGNORE\r\n"; // + "BOX 20 20 570 380 8\r\n";
            		cpclConfigLabel += "T 0 3 48 48 " + text[1] + "\r\n";  
            		cpclConfigLabel += "T 0 3 48 98 " + text[2] + "\r\n";
            		cpclConfigLabel += "T 0 3 48 148 " + text[3] + "\r\n";
            		cpclConfigLabel += "T 0 3 48 198 " + text[4] + "\r\n";
            		cpclConfigLabel += "B 128 3 30 40 48 248 " + text[0] + "\r\n\r\n\r\n\r\n";
            		cpclConfigLabel += "PRINT\r\n";

            	return cpclConfigLabel.getBytes();
		}

		// write label to printer
		private void sendTestLabel(BluetoothConnection connection, ZebraPrinter printer, String[] text) {
	        try {
	            byte[] configLabel = getConfigLabel(printer, text);
	            connection.write(configLabel);

	        } catch (ConnectionException e) {
	        	e.printStackTrace();
	        } finally {
	            disconnect(connection);
	        }
	    }

		// disconnect from the printer
	    private void disconnect(BluetoothConnection connection) {
	        try {
	            if (connection != null) {
	                connection.close();
	            }
	        } catch (ConnectionException e) {
	        	e.printStackTrace();
	        }
	    }
		
	    // gets the async result from the pair activity or the request to enable BT
		public void onActivityResult(int requestCode, int resultCode, Intent data) {
	        Log.d(TAG, "onActivityResult " + resultCode);
	        switch (requestCode) {
	        case REQUEST_PAIR_DEVICE:
	            // When DeviceListActivity returns with a device to connect
	            if (resultCode == Activity.RESULT_OK) {
	            	String address = data.getExtras().getString(PairActivity.EXTRA_DEVICE_ADDRESS);
	            	if ((address == null) || (address.isEmpty())) {
	            		setPairedDevice("None");
	            	}
	            	else
	            	{
	            		setPairedDevice(address);
	            		printLabel();
	            	}
	        		Log.d(TAG, "BT address returned from pair activity: " + mPairedPrinterAddress);
	            }
	            break;
	        case REQUEST_ENABLE_BT:
	            // When the request to enable Bluetooth returns
	            if (resultCode == Activity.RESULT_OK) {
	            	Log.d(TAG, "BT enabled");
	            } else {
	                // User did not enable Bluetooth or an error occurred
	                Log.d(TAG, "BT not enabled");
	                Toast.makeText(this, "Unable to enable BT", Toast.LENGTH_SHORT).show();
	                finish();
	            }
	        }
	    }
		
		// shows/hides progress indicator
		private void showProgressIndicator(boolean show) {
			if (show) {
				View progress = findViewById(R.id.progressBar1);
				if (progress != null) {
					progress.setVisibility(View.VISIBLE);
				}
			}
			else {
				View progress = findViewById(R.id.progressBar1);
				if (progress != null) {
					progress.setVisibility(View.GONE);
				}
			}
		}
		
		// enables/disables the print button
		private void enablePrintButton(boolean enabled) {
			Button printButton = (Button) findViewById(R.id.printButton);
			if (printButton != null) {
				printButton.setEnabled(enabled);
			}
		}

		// updates the device name in the UI
	    public void updateDeviceName() {
	    	/*
	    	 * MLW

	    	TextView tv = (TextView)findViewById(R.id.printerLabel);
	    	if (tv != null) {
	    		tv.setText(mPairedPrinterAddress);
	    	}
	    		    	 */
	    }
	    
	    // sets the currently paired device
	    public void setPairedDevice(String address) {
	    	mPairedPrinterAddress = address;
			SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
			prefs.edit().putString("printerAddress", mPairedPrinterAddress).commit();
			updateDeviceName();
	    }	
	    
	    
	    
	    
	    
}