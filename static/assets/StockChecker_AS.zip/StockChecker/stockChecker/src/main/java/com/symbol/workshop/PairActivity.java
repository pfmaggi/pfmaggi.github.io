package com.symbol.workshop;

import java.util.Set;

import android.app.Activity;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.symbol.emdk.EMDKManager;
import com.symbol.emdk.EMDKManager.EMDKListener;
import com.symbol.emdk.EMDKManager.FEATURE_TYPE;
import com.symbol.emdk.EMDKResults;
import com.symbol.emdk.EMDKResults.STATUS_CODE;
import com.symbol.emdk.ProfileManager;
import com.symbol.emdk.ProfileManager.PROFILE_FLAG;


public class PairActivity extends Activity implements EMDKListener {

	public static final String TAG = "PairActivity";

	// printer name that we want to pair to
	private String mPrinterToPair = null;
	// printer BT address
	private String mPrinterBTAddr = null;

	// keep track of if we are currently discovering devices
	private Boolean mDiscovering = false;
	// keep track of whether we found the device we are looking for
	private Boolean mDeviceFound = false;

	private BluetoothAdapter mBluetoothAdapter = null;
	
	private NfcAdapter adapter = null;

	// Return Intent extra
	public static String EXTRA_DEVICE_ADDRESS = "device_address";

	EMDKManager mEmdkManager = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pair);
		
		// get BT adapter from system
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if (mBluetoothAdapter == null) {
		    Toast.makeText(this, "Device doesn't support bluetooth!", Toast.LENGTH_LONG).show();
		    finish();
		}
		
		adapter = NfcAdapter.getDefaultAdapter(this);
		
		if (adapter == null)
		{
			TextView msg = (TextView) findViewById(R.id.textView1);
			msg.setText(getResources().getString (R.string.scan_to_pair));
		}

		
		// open connection to the EMDK
		EMDKManager.getEMDKManager(this, this);
		
		// restore state in case of orientation change
		if (savedInstanceState != null) {
			mPrinterToPair = savedInstanceState.getString("printerToPair");
			mPrinterBTAddr = savedInstanceState.getString("printerBTAddr");
			mDiscovering = savedInstanceState.getBoolean("discovering");
			mDeviceFound = savedInstanceState.getBoolean("deviceFound");
			
			View progress = findViewById(R.id.progressBar1);
			if (progress != null) {
				progress.setVisibility((savedInstanceState.getBoolean("progressState", false) ? View.VISIBLE : View.GONE));
			}
		}
	}

	@Override
	protected void onStart() {
		// register broadcast receivers
		IntentFilter filter = new IntentFilter();
		filter.addAction(BluetoothDevice.ACTION_FOUND);
		filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
		filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
		registerReceiver(mDiscoveryReceiver, filter);
		registerReceiver(mScanReceiver, new IntentFilter(
				"com.symbol.example.zebraprintdemo.scantopair"));
				
		super.onStart();
	}
	
	@Override
	protected void onResume()
	{
	if (adapter != null)
	{
	PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
            new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
        IntentFilter tagDetected = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
        IntentFilter filter2     = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
        IntentFilter[] filters = new IntentFilter[] { tagDetected,filter2 };
		adapter.enableForegroundDispatch(this, pendingIntent, filters, null);
		
		super.onResume();
	}
	}

	@Override
	protected void onStop() {
		// unregister broadcast receivers
		unregisterReceiver(mScanReceiver);
		unregisterReceiver(mDiscoveryReceiver);
		super.onStop();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		if (adapter != null)
		{
			adapter.disableForegroundDispatch(this);
		}
	}


	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// save state
		outState.putString("printerToPair", mPrinterToPair);
		outState.putString("printerBTAddr", mPrinterBTAddr);
		outState.putBoolean("discovering", mDiscovering);
		outState.putBoolean("deviceFound", mDeviceFound);
		View progress = findViewById(R.id.progressBar1);
		if (progress != null) {
			outState.putBoolean("progressState", (progress.getVisibility() == View.VISIBLE) ? true : false);
		}
		super.onSaveInstanceState(outState);
	}

	@Override
	protected void onDestroy() {
		// release EMDK resources
		if (mEmdkManager != null) {
			mEmdkManager.release();
		}
		super.onDestroy();
	}
	
	   public void onNewIntent(Intent intent)
	   {
		    setIntent(intent);
		   	if(getIntent().getAction().equals(NfcAdapter.ACTION_TAG_DISCOVERED))
		   	{
	            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
	            readFromTag(getIntent(), tag);         
	        }
	   }
	   
		private boolean readFromTag(Intent intent, Tag tag)
		{
			NdefMessage[] ndefMessages=null;
			Ndef ndef = Ndef.get(tag);
			try
			{
				 Parcelable[] messages = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES); 
				 if (messages != null)
				 {
		                ndefMessages = new NdefMessage[messages.length];
		                for (int i = 0; i < messages.length; i++)
		                {
		                    ndefMessages[i] = (NdefMessage) messages[i];
		                }
				 }
				 NdefRecord record = ndefMessages[0].getRecords()[0];
	             byte[] payload = record.getPayload();
	             String text = new String(payload);
	                          
	             // Extract Bluetooth Mac address from NFC tag data 
	             findMacAddr(text);
	             ndef.close();
	             returnWithBTAddress();
	             
			 }
		     catch (Exception e)
		     {
		     }
			
	        return true;
		}
		
		private void findMacAddr(String nfcData)
		{
			int index = 0;
			index = nfcData.indexOf("&mB=");
			mPrinterBTAddr = formatMAC(nfcData.substring(index+4, index+16).toUpperCase());
		}
		
		
	       private String formatMAC(String str)
	       {
	            String MAC = "";
	            int len = str.length();

	            for (int i = 1 ; i <= len ; ++i)
	            {
	                MAC += str.charAt(i - 1);
	                if ((i % 2 == 0) && i < len)
	                {
	                    MAC += ":";
	                }
	            }
	            
	            return MAC;
	        }


	// handle events from scanner
	BroadcastReceiver mScanReceiver = new BroadcastReceiver() {
	
		@Override
		public void onReceive(Context context, Intent intent) {
			Log.d(TAG, "Got scan receiver");
			String barcodeData = intent
					.getStringExtra("com.symbol.datawedge.data_string");
			Log.d(TAG, "Scan Data: " + barcodeData);
			if (barcodeData != null) {
				// start pairing process
				mPrinterToPair = barcodeData;
				connectDevice();
			}
		}
	};

	@Override
	public void onClosed() {
		Log.d(TAG, "EMDK closed");
	}

	// emdk opened handler
	@Override
	public void onOpened(EMDKManager mgr) {
		// apply emdk profile
		mEmdkManager = mgr;
		if (mEmdkManager != null) {
			ProfileManager profileMgr = (ProfileManager) mEmdkManager
					.getInstance(FEATURE_TYPE.PROFILE);
			if (profileMgr != null) {
				EMDKResults result = profileMgr.processProfile("PrintDemo",
						PROFILE_FLAG.SET, new String[1]);
				if (!result.statusCode.equals(STATUS_CODE.SUCCESS)) {
					Log.d(TAG, "Failed to set profile");
				}
			}
		}
	}

	// show/hide the progress indicator
	private void showProgressIndicator(boolean show) {
		if (show) {
			findViewById(R.id.progressBar1).setVisibility(View.VISIBLE);
		} else {
			findViewById(R.id.progressBar1).setVisibility(View.GONE);
		}
	}

	// connect to scanned bt name
	private void connectDevice() {
		showProgressIndicator(true);

		// Get a set of currently paired devices
		if (mPrinterToPair != null) {
			Log.d(TAG, "Device selected: " + mPrinterToPair);
			Set<BluetoothDevice> pairedDevices = mBluetoothAdapter
					.getBondedDevices();
			if ((pairedDevices != null) && (!pairedDevices.isEmpty())) {
				for (BluetoothDevice bluetoothDevice : pairedDevices) {
					if ((bluetoothDevice.getName() != null)
							&& (bluetoothDevice.getName()
									.equals(mPrinterToPair))) {
						// printer is already paired, just return to main activity with BT addr
						Toast.makeText(this, "Printer selected",
								Toast.LENGTH_LONG).show();
						showProgressIndicator(false);
						mPrinterBTAddr = bluetoothDevice.getAddress();
						returnWithBTAddress();
						return;
					}
				}
			}
		}

		// printer is not already paired, start discovery process
		mDiscovering = true;
		mDeviceFound = false;
		mBluetoothAdapter.cancelDiscovery();
		mBluetoothAdapter.startDiscovery();
	}
	
	// return to main activity
	private void returnWithBTAddress() {
		Intent returnIntent = new Intent();
		
		// set the result to bt address and finish activity
		returnIntent.putExtra(EXTRA_DEVICE_ADDRESS, mPrinterBTAddr);
		setResult(RESULT_OK, returnIntent);
		finish();
	}

	// handle events related to BT discovery
	private final BroadcastReceiver mDiscoveryReceiver = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			if (mDiscovering) {
				if (intent.getAction().equals(
						BluetoothAdapter.ACTION_DISCOVERY_STARTED)) {
					Log.d(TAG, "Discovery started");
				} else if (intent.getAction().equals(
						BluetoothAdapter.ACTION_DISCOVERY_FINISHED)) {
					Log.d(TAG, "Discovery finished");
					showProgressIndicator(false);
					mDiscovering = false;
					if (!mDeviceFound) {
						Toast.makeText(
								context,
								"Unable to find printer, ensure it is powered on and try again",
								Toast.LENGTH_LONG).show();
					}
				} else if (intent.getAction().equals(
						BluetoothDevice.ACTION_FOUND)) {
					BluetoothDevice device = intent
							.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
					if (device != null) {
						Log.d(TAG, "Name: " + device.getName() + ", Address: "
								+ device.getAddress());
						if ((device.getName() != null)
								&& (device.getName().equals(mPrinterToPair))) {
							// we found the device we were looking for
							// cancel the discovery and request a pairing
							mBluetoothAdapter.cancelDiscovery();
							mDiscovering = false;
							Log.d(TAG, "Found printer, storing BT addr");
							mPrinterBTAddr = device.getAddress();
							showProgressIndicator(false);
							returnWithBTAddress();
						}
					}
				}
			}
		}
	};
}
