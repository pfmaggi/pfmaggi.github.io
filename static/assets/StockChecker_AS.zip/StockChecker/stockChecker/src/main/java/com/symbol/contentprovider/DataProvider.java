package com.symbol.contentprovider;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

public class DataProvider extends ContentProvider
{
	public static final String PROVIDER_NAME = "com.symbol.database.provider";
	public static final String STOCK_DATABASE_TABLE = "stock";
	public static final String UPDATE_DATABASE_TABLE = "updates";
	public static final Uri STOCK_URI = Uri.parse("content://" + PROVIDER_NAME + "/" + STOCK_DATABASE_TABLE);
	public static final Uri UPDATE_URI = Uri.parse("content://" + PROVIDER_NAME + "/" + UPDATE_DATABASE_TABLE);
	public static final String STOCK_CODE = "code";
	public static final String STOCK_DESCRIPTION = "description";
	public static final String STOCK_QUANTITY = "qty";
	public static final String STOCK_PRICE = "price";
	public static final String REMOVE_UPDATE_FLAG = "_update_flag";
	private static final int DATABASE_VERSION = 1;
	private static final int STOCK_DATABASE_TABLE_DIR = 1;
	private static final int STOCK_DATABASE_TABLE_ITEM = 2;
	private static final int UPDATE_DATABASE_TABLE_ITEM = 3;
	private static final String TAG = "Provider";
	private static final String DATABASE_NAME = "stock.db";
	private static final String CONTENT_STOCK_ITEM = ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" + STOCK_DATABASE_TABLE;
	private static final String CONTENT_STOCK_DIR = ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + STOCK_DATABASE_TABLE;
	private Context mContext;

	// URI Matcher Table
	private static final UriMatcher sURIMatcher = new UriMatcher(UriMatcher.NO_MATCH);
	static
	{
		sURIMatcher.addURI(PROVIDER_NAME, STOCK_DATABASE_TABLE, STOCK_DATABASE_TABLE_DIR);
		sURIMatcher.addURI(PROVIDER_NAME, STOCK_DATABASE_TABLE + "/*", STOCK_DATABASE_TABLE_ITEM);
		sURIMatcher.addURI(PROVIDER_NAME, UPDATE_DATABASE_TABLE, UPDATE_DATABASE_TABLE_ITEM);
	}

	// Locals
	private SQLiteDatabase StorageDB;

	/*********************************************************************************************************/
	private static class DatabaseHelper extends SQLiteOpenHelper
	{
		public DatabaseHelper(Context context)
		{
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db)
		{

			// Create City Table
			db.execSQL("CREATE TABLE " + STOCK_DATABASE_TABLE + "(" 
					+ STOCK_CODE + " TEXT PRIMARY_KEY UNIQUE NOT NULL," 
					+ STOCK_DESCRIPTION + " TEXT NOT NULL DEFAULT ''," 
					+ STOCK_PRICE + " NUMERIC NOT NULL DEFAULT '0'," 
					+ STOCK_QUANTITY + " NUMERIC NOT NULL DEFAULT '0')");

			// Table for any updated rows in table
			db.execSQL("CREATE TABLE " + UPDATE_DATABASE_TABLE + "(" 
					+ "'code' TEXT PRIMARY_KEY UNIQUE NOT NULL," 
					+ "'update_type' INT NOT NULL ); ");

			// Create Database Trigger when updates happen
			db.execSQL("CREATE TRIGGER IF NOT EXISTS update_stock AFTER UPDATE ON 'stock' " 
					+ "BEGIN " + "INSERT OR REPLACE INTO " + UPDATE_DATABASE_TABLE + "(code,update_type) "
					+ "VALUES(new.code,1); " + "END;");

			// Create Database Trigger when Inserts happen
			db.execSQL("CREATE TRIGGER IF NOT EXISTS insert_stock AFTER INSERT ON 'stock' " 
					+ "BEGIN " + "INSERT OR REPLACE INTO " + UPDATE_DATABASE_TABLE + "(code,update_type) "
					+ "VALUES(new.code,1); " + "END;");

			db.execSQL("CREATE TRIGGER IF NOT EXISTS delete_stock AFTER DELETE ON 'stock' " 
					+ "BEGIN " + "INSERT OR REPLACE INTO " + UPDATE_DATABASE_TABLE + "(code,update_type) "
					+ "VALUES(old.code,2); " + "END;");

		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
		{
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion + " which will destroy all old data");
			db.execSQL("DROP TABLE IF EXISTS " + STOCK_DATABASE_TABLE);
			db.execSQL("DROP TABLE IF EXISTS " + UPDATE_DATABASE_TABLE);
			onCreate(db);
		}
	}

	/*********************************************************************************************************/
	public boolean onCreate()
	{
		mContext = getContext();
		DatabaseHelper dbHelper = new DatabaseHelper(mContext);
		StorageDB = dbHelper.getWritableDatabase();
		return (StorageDB == null) ? false : true;
	}

	/*********************************************************************************************************/
	public synchronized int delete(Uri uri, String selection, String[] selectionArgs)
	{
		int count = 0;

		switch (sURIMatcher.match(uri))
		{
		// Delete Entry from Stock Table
		case STOCK_DATABASE_TABLE_DIR:
			count = StorageDB.delete(STOCK_DATABASE_TABLE, selection, selectionArgs);
			break;

		// Delete an entry the Stock table where code is passed in
		case STOCK_DATABASE_TABLE_ITEM:
			String code = uri.getLastPathSegment();
			if (TextUtils.isEmpty(selection))
			{
				count = StorageDB.delete(STOCK_DATABASE_TABLE, STOCK_CODE + "='" + code + "'", null);
			} else
			{
				count = StorageDB.delete(STOCK_DATABASE_TABLE, STOCK_CODE + "='" + code + "' and " + selection, selectionArgs);
			}
			break;

		// Delete an Entry from Update Table
		case UPDATE_DATABASE_TABLE_ITEM:
			count = StorageDB.delete(UPDATE_DATABASE_TABLE, selection, selectionArgs);
			break;

		default:
			throw new IllegalArgumentException("Unsupported URI: " + uri);
		}

		getContext().getContentResolver().notifyChange(uri, null, true);
		return count;
	}

	/*********************************************************************************************************/
	public String getType(Uri uri)
	{
		switch (sURIMatcher.match(uri))
		{
		case STOCK_DATABASE_TABLE_DIR:
			return CONTENT_STOCK_DIR;
		case STOCK_DATABASE_TABLE_ITEM:
			return CONTENT_STOCK_ITEM;

		default:
			throw new IllegalArgumentException("Unsupported URI: " + uri);
		}
	}

	/*********************************************************************************************************/
	public synchronized Uri insert(Uri uri, ContentValues values)
	{
		Boolean removeFlag = false;

		switch (sURIMatcher.match(uri))
		{
		// Insert or Replace Stock Item
		case STOCK_DATABASE_TABLE_DIR:
			if (values.containsKey(REMOVE_UPDATE_FLAG))
			{
				values = new ContentValues(values);
				values.remove(REMOVE_UPDATE_FLAG);
				removeFlag = true;
			}

			// Add or Replace new Entry into database
			StorageDB.replace(STOCK_DATABASE_TABLE, null, values);

			// Remove the insert from the updates table, if request was from Sync
			// Adapter
			if (removeFlag)
			{
				String sql = "DELETE FROM " + UPDATE_DATABASE_TABLE + " WHERE code='" + values.get("code") + "'";
				StorageDB.execSQL(sql);
			}
			break;

		default:
			throw new IllegalArgumentException("Unsupported URI: " + uri);
		}
		getContext().getContentResolver().notifyChange(uri, null, !removeFlag);
		return Uri.parse(PROVIDER_NAME + "/" + STOCK_DATABASE_TABLE + "/" + values.get(STOCK_CODE));
	}

	/*********************************************************************************************************/
	public synchronized Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder)
	{
		SQLiteQueryBuilder builder = new SQLiteQueryBuilder();

		switch (sURIMatcher.match(uri))
		{
		// City Directory List
		case STOCK_DATABASE_TABLE_DIR:
			builder.setTables(STOCK_DATABASE_TABLE);
			break;

		case STOCK_DATABASE_TABLE_ITEM:
			builder.setTables(STOCK_DATABASE_TABLE);
			builder.appendWhere(STOCK_CODE + "='" + uri.getLastPathSegment() + "'");
			break;

		case UPDATE_DATABASE_TABLE_ITEM:
			builder.setTables(UPDATE_DATABASE_TABLE);
			break;

		default:
			throw new IllegalArgumentException("Unsupported URI: " + uri);

		}
		Cursor cursor = builder.query(StorageDB, projection, selection, selectionArgs, null, null, sortOrder);
		cursor.setNotificationUri(getContext().getContentResolver(), uri);
		return cursor;
	}

	/*********************************************************************************************************/
	public synchronized int update(Uri uri, ContentValues values, String selection, String[] selectionArgs)
	{
		int count = 0;

		switch (sURIMatcher.match(uri))
		{
		case STOCK_DATABASE_TABLE_DIR:
			count = StorageDB.update(STOCK_DATABASE_TABLE, values, selection, selectionArgs);
			break;

		case STOCK_DATABASE_TABLE_ITEM:
			count = StorageDB.update(STOCK_DATABASE_TABLE, values, STOCK_CODE + "='" + uri.getLastPathSegment() + "'", null);
			break;

		default:
			throw new IllegalArgumentException("Unsupported URI: " + uri);
		}

		getContext().getContentResolver().notifyChange(uri, null, true);
		return count;
	}

}
