package com.symbol.workshop;

import android.accounts.Account;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.symbol.contentprovider.DataProvider;

public class BarcodeEntry extends Activity
{	
	@Override 
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_barcode_entry);
		
		context = this;			
		barcode = (TextView)findViewById(R.id.barcode);
		barcode.setOnFocusChangeListener(focusListener);
		description = (TextView)findViewById(R.id.description);
		price = (TextView)findViewById(R.id.price);
		quantity = (TextView)findViewById(R.id.quantity);
		button = (Button) findViewById(R.id.addButton);
		
	   	intentFilter = new IntentFilter();
    	intentFilter.addAction("com.symbol.workshop.LOOKUP");
    	EMDKreceiver = new EMDKReceiver();
    	this.registerReceiver(EMDKreceiver, intentFilter, null, null);
		
		inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		
		addSetDataButtonListener();
	}
	
	private void addSetDataButtonListener(){
		
	    Button buttonVersion = (Button) findViewById(R.id.addButton);
	    buttonVersion.setOnClickListener(new OnClickListener() {

	    	@Override
			public void onClick(View arg0) {
	    			
	    		/*
	    		 * Lower the keyboard after button is clicked to expose the full screen.
	    		 */

	    		inputMethodManager.hideSoftInputFromWindow(barcode.getWindowToken(), 0);

	    		String product_barcode = barcode.getText().toString();
	    		String product_description = description.getText().toString().trim();
	    		String product_quantity = quantity.getText().toString().trim();
	    		String product_price = price.getText().toString().trim();
	    		
				if (product_barcode == null || (product_barcode.trim()).isEmpty())
				{
					Toast.makeText(context, "Barcode Required", Toast.LENGTH_LONG).show();
					return;
				}
				
				try
				{
					ContentResolver contentResolver = getContentResolver();
					ContentValues vals = new ContentValues();
					vals.put(DataProvider.STOCK_CODE, product_barcode);
					vals.put(DataProvider.STOCK_DESCRIPTION, product_description);
					vals.put(DataProvider.STOCK_PRICE, product_price);
					vals.put(DataProvider.STOCK_QUANTITY, product_quantity);
							
					contentResolver.insert(DataProvider.STOCK_URI, vals);
					Toast.makeText(context, "Item: " + product_barcode + " added", Toast.LENGTH_LONG).show();
					
					/*
					 * Force an update with the server
					 */
					Account account = new Account("Symbol", "com.symbol.database.account");
					Bundle bundle = new Bundle();
					ContentResolver.requestSync(account, "com.symbol.database.provider", bundle);

				}
				catch(Exception ex)
				{
					Toast.makeText(context, "Failed adding item: " + product_barcode + ". Cause:" + ex.getMessage(), Toast.LENGTH_LONG).show();
				}			
			}
		});
	    
	}
	
	private OnFocusChangeListener focusListener = new OnFocusChangeListener()
	{
		@Override
		public void onFocusChange(View view, boolean hasFocus)
		{
				if (hasFocus == false)
				{
					String product_barcode = barcode.getText().toString();
					if (product_barcode != null && (product_barcode.trim()).isEmpty() == false)
					{
						/*
						 * EMDK profile must not include "\n" for intents.
						 */			
						lookupProduct(product_barcode);
					}
				}	
		}
	};

	
	   @Override
	    protected void onResume()
	   {
	        super.onResume();
	        registerReceiver(EMDKreceiver, intentFilter);
	    }

	    @Override
	    protected void onPause()
	    {
	        super.onPause();
	        unregisterReceiver(EMDKreceiver);
	    }
	
	    public class EMDKReceiver extends BroadcastReceiver
	    {
			@Override
			public void onReceive(Context context, Intent intent)
			{
				String product_barcode = intent.getStringExtra("com.symbol.emdk.datawedge.data_string");
				if (product_barcode != null && (product_barcode.trim()).isEmpty() == false)
				{
					lookupProduct(product_barcode);
				}
			}
	    }
	    
		private void lookupProduct(String code)
		{
				/*
				 * Try to find barcode in database.
				 */
			Cursor c = getContentResolver().query(DataProvider.STOCK_URI,
													null,
													DataProvider.STOCK_CODE + "= ?" ,
													new String[] { code },
													null);
			barcode.setText(code);		
			if (c != null && c.getCount() != 0)
			{
				inputMethodManager.hideSoftInputFromWindow(barcode.getWindowToken(), 0);
				c.moveToFirst();					
				description.setText(c.getString(c.getColumnIndex(DataProvider.STOCK_DESCRIPTION)));
				price.setText(c.getString(c.getColumnIndex(DataProvider.STOCK_PRICE)));
				quantity.setText(c.getString(c.getColumnIndex(DataProvider.STOCK_QUANTITY)));
				
				button.setText("Update");
			}
			else
			{
				button.setText("Add");
			}
		}
	
	

	private Context context = null;
	private TextView barcode = null;
	private TextView description = null;
	private TextView price = null;
	private TextView quantity = null;
	private Button button = null;
	private IntentFilter intentFilter = null;
	private EMDKReceiver EMDKreceiver = null;
	private InputMethodManager inputMethodManager = null;
	

	
}