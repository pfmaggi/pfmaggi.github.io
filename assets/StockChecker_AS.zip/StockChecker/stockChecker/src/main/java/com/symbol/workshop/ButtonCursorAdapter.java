package com.symbol.workshop;

import android.widget.SimpleCursorAdapter;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;


/*
 * The purpose of this class is to add/modify data with each row
 * of the list that is displayed on the screen, by overriding
 * the getView method.  In this case we simply modify the 
 * background color of each row.
 */

class ButtonCursorAdapter extends SimpleCursorAdapter
{	
        public ButtonCursorAdapter(	Context c,
        							int layout,
        							Cursor cursor,
        							String[] from,
        							int[] to,
        							int flags)
        {
            super(c, layout, cursor, from, to, flags);
        }
             
        @Override 
        public
        View getView(int position, View convertView, ViewGroup parent)
        {

            View v = super.getView(position, convertView, parent);
            
            if (position % 2 == 0)
            { 
                v.setBackgroundColor(Color.argb(230,238, 233, 233));
            }
            else
            {
                v.setBackgroundColor(Color.argb(230,255, 255, 255));
            }
            
            return v;
        }
}
