package com.symbol.mqtt;


import com.symbol.workshop.R;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.Notification.Builder;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.provider.Settings.Secure;
import android.util.Log;


public class MQTT extends Service
{
	private static Class<?> launchActivity = null;
	static boolean serviceRunning = false;
	private static int mid = 0;
	private static Connection connection = null;
	

	/*
	 * FIXME pull this from a shared preference
	 */
   
	final static int MIN_TIMEOUT = 1000; // milliseconds
	final static int MAX_TIMEOUT = 32000; // Geometric back-off
    final static String host = "stockchecker.emb-sc.com";
    final static int port = 11883;
    
    final static String uri = "tcp://" + host + ":" + port;
   
 
	@Override
	public void onCreate()
	{
		super.onCreate();
		connection = new Connection(MIN_TIMEOUT, MAX_TIMEOUT);
	}
		
	@Override
	public int onStartCommand(Intent intent, int flags, int startId)
	{
		if (isRunning())
		{
			return START_STICKY;
		}
		
		super.onStartCommand(intent, flags, startId);    		   	      
	    connection.start();
	    
		return START_STICKY;
	}
	
	@Override
	public void onDestroy()
	{
		connection.getHandler().sendMessage(Message.obtain(null, Connection.STOP));
		connection = null;
	}
	
	@Override
	public IBinder onBind(Intent intent)
	{
		return null;
	}
	
	 private synchronized static boolean isRunning()
	 {
		 if (serviceRunning == false)
		 {
			 serviceRunning = true;
			 return false;
		 }
		 
		 return true;
	 }
	 
	public static void setPushCallback(Class<?> activityClass)
	{
		launchActivity = activityClass;
	}
		
	private enum CONNECT_STATE
	{
		DISCONNECTED,
		CONNECTING,
		CONNECTED
	}
	
	
	private class Connection extends Thread
	{
		private MsgHandler msgHandler = null;
		public static final int STOP = 0;
		public static final int CONNECT = 1;
		public static final int RESETTIMER = 2;
		private CONNECT_STATE connState = CONNECT_STATE.DISCONNECTED;
		
		Connection(int min, int max)
		{
			msgHandler = new MsgHandler(min, max);
			msgHandler.sendMessage(Message.obtain(null, Connection.CONNECT));
		}
		
		private MsgHandler getHandler()
		{
			return msgHandler;
		}
	
		private class MsgHandler extends Handler implements MqttCallback
		{
			private Intent broadcastIntent = new Intent();
			private int min_timeout;
			private int max_timeout;
			private int timeout;
			private MqttClient client = null;
			private MqttConnectOptions options = null;
			
			MsgHandler(int min, int max)
			{
				min_timeout = min;
				max_timeout = max;
				timeout = min;
				options = new MqttConnectOptions();
				options.setCleanSession(true);
				
			    try
				{
					client = new MqttClient(uri, Secure.getString(getContentResolver(), Secure.ANDROID_ID) , null);
					client.setCallback(this);
				}
			    catch (MqttException e1)
				{
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
			}

			@Override
			public void handleMessage(Message msg)
			{
				switch (msg.what)
				{
				case STOP:
				{
					try
					{
						client.disconnect();
					} catch (MqttException e)
					{
						e.printStackTrace();
					}
					
					getLooper().quit();
				}
				case CONNECT:
				{
					if (connState != CONNECT_STATE.CONNECTED)
					{
					    try
						{
							client.connect(options);
							connState = CONNECT_STATE.CONNECTED;
							Log.d(getClass().getCanonicalName(), "Connected");
							client.subscribe("updates");
							if (timeout != min_timeout)
							{
								this.sendMessageDelayed(Message.obtain(null, Connection.RESETTIMER), timeout);
							}
						}
					    catch (MqttException e)
						{				    	
					    	Log.d(getClass().getCanonicalName(), "Connection attemp failed with reason code = " + e.getReasonCode() + e.getCause());
							if (timeout < max_timeout)
							{
								timeout *= 2;
							}
					    	this.sendMessageDelayed(Message.obtain(null, Connection.CONNECT), timeout);
					    	return;
						}
					}
				}
				case RESETTIMER:
				{
					timeout = min_timeout;
				}
				}
			}
			
			@Override
			public void connectionLost(Throwable arg0)
			{
				Log.d(getClass().getCanonicalName(), "connectionLost");
				connState = CONNECT_STATE.DISCONNECTED;
				sendMessageDelayed(Message.obtain(null, Connection.CONNECT), timeout);
			}

			@Override
			public void deliveryComplete(IMqttDeliveryToken arg0)
			{
			}

			@Override
			public void messageArrived(String topic, MqttMessage message) throws Exception
			{
				Log.d(getClass().getCanonicalName(), message.toString());
				
				broadcastIntent.setAction("com.symbol.update");
				sendBroadcast(broadcastIntent);
				
				if (launchActivity != null)
				{
					Context context = getBaseContext();
					Intent intent = new Intent(context, launchActivity);
					intent.setAction(Intent.ACTION_MAIN);
					intent.addCategory(Intent.CATEGORY_LAUNCHER);
					
					//build the pending intent that will start the appropriate activity
					PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, 0);
					
					//build the notification
					Builder notificationCompat = new Builder(context);
					notificationCompat.setAutoCancel(true)  
					        .setContentIntent(pendingIntent)
					        .setContentText( message.toString())
					        .setSmallIcon(R.drawable.ic_launcher);

					Notification notification = notificationCompat.build();		   
					NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
					nm.notify(mid++, notification);
				}
			}
		}
	}
}
